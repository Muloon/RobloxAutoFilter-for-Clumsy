



This autohotkey program is used to automatically obtain Roblox's current Server IP and automatically set Clumsy to the ideal settings for Roblox.

A Clumsy toggle is also assigned here, which will happen at start if no config.ini is present.

This Clumsy toggle will both toggle Clumsy 3.0, and start Clumsy if it is not present and toggle it at the same time with ideal Roblox settings.

RobloxAutoIP needs administrative privlages to both launch Clumsy and to remotely toggle Clumsy.

Roblox must both be active and in-game.

With this Clumsy will only impact Roblox's network traffic and nothing else.

If you ever wish to change the Clumsy toggle hotkey, delete the config.ini and restart RobloxAutoIP

Every sound can also be changed by replacing them with .wav files using the same corresponding names, a few sound packs are provided.